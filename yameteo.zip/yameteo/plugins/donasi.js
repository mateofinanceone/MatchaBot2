let handler = async m => m.reply(`
╭─「 Donasi • GoPay/Pulsa 」
│ • Tri [6289526814882]
│ • Tri [0895703139560]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
